angular.module('app.LoginCtrl',['ngMessages','gp.rutValidator','selectize'])
.controller('LoginCtrl',['$scope',function($scope){
  }]);